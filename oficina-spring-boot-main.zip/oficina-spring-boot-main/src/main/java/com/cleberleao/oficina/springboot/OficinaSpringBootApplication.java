package com.cleberleao.oficina.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OficinaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OficinaSpringBootApplication.class, args);
	}

}
